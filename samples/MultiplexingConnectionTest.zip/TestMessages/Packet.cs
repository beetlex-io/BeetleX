﻿using BeetleX;
using BeetleX.Buffers;
using BeetleX.Clients;
using BeetleX.EventArgs;
using BeetleX.Packets;
using System;
using System.Collections.Generic;
using System.Text;

namespace TestMessages
{
    static class ObjectSerializeExpand
    {

        public static void Serialize(this object data, System.IO.Stream stream)
        {
            ProtoBuf.Meta.RuntimeTypeModel.Default.Serialize(stream, data);
        }

        public static object Deserialize(this System.IO.Stream stream, object data, int length, Type type)
        {
            return ProtoBuf.Meta.RuntimeTypeModel.Default.Deserialize(stream, data, type, length);
        }

        public static object Deserialize(this System.IO.Stream stream, int length, Type type)
        {
            return ProtoBuf.Meta.RuntimeTypeModel.Default.Deserialize(stream, null, type, length);
        }
        public static T Deserialize<T>(this System.IO.Stream stream, int length)
        {
            return (T)Deserialize(stream, length, typeof(T));
        }
    }


    public class ProtobufClientPacket : FixeHeaderClientPacket
    {
        public ProtobufClientPacket()
        {

        }


        public static Type mEmployee = typeof(Employee);

        public static Type mSearchEmployee = typeof(SearchEmployee);

        public IMessageTypeHeader TypeHeader { get; set; }

        public override IClientPacket Clone()
        {
            ProtobufClientPacket result = new ProtobufClientPacket();

            return result;
        }

        protected override object OnRead(IClient client, PipeStream stream)
        {
            int t = stream.ReadInt32();
            int bodySize = stream.ReadInt32();
            if (t == 1)
                return stream.Deserialize(bodySize, mEmployee);
            else
                return stream.Deserialize(bodySize, mSearchEmployee);
        }

        protected override void OnWrite(object data, IClient client, PipeStream stream)
        {
            if (data is Employee)
                stream.Write(1);
            else
                stream.Write(2);
            MemoryBlockCollection bodysize = stream.Allocate(4);
            int bodyStartlegnth = (int)stream.CacheLength;
            ProtoBuf.Meta.RuntimeTypeModel.Default.Serialize(stream, data);
            bodysize.Full((int)stream.CacheLength - bodyStartlegnth);
        }
    }

    public class ProtobufPacket : FixedHeaderPacket
    {
        public ProtobufPacket()
        {

        }

        public static Type mEmployee = typeof(Employee);

        public static Type mSearchEmployee = typeof(SearchEmployee);

        private PacketDecodeCompletedEventArgs mCompletedEventArgs = new PacketDecodeCompletedEventArgs();

        public override IPacket Clone()
        {
            ProtobufPacket result = new ProtobufPacket();

            return result;
        }

        protected override object OnReader(ISession session, PipeStream stream)
        {
            int t = stream.ReadInt32();
            int bodySize = stream.ReadInt32();
            if (t == 1)
                return stream.Deserialize(bodySize, mEmployee);
            else
                return stream.Deserialize(bodySize, mSearchEmployee);
        }

        protected override void OnWrite(ISession session, object data, PipeStream stream)
        {
            if (data is Employee)
                stream.Write(1);
            else
                stream.Write(2);
            MemoryBlockCollection bodysize = stream.Allocate(4);
            int bodyStartlegnth = (int)stream.CacheLength;
            ProtoBuf.Meta.RuntimeTypeModel.Default.Serialize(stream.Stream, data);
            bodysize.Full((int)stream.CacheLength - bodyStartlegnth);
        }
    }




}
