﻿using BeetleX.Buffers;
using ProtoBuf;
using System;
using System.Collections.Generic;

namespace TestMessages
{
    [ProtoContract]
    public class Employee 
    {
        [ProtoMember(1)]
        public int EmployeeID
        {
            get;
            set;
        }
        [ProtoMember(2)]
        public string LastName
        {
            get;
            set;
        }
        [ProtoMember(3)]
        public string FirstName
        {
            get;
            set;
        }
        [ProtoMember(4)]
        public string Address { get; set; }
        [ProtoMember(5)]
        public string City { get; set; }
        [ProtoMember(6)]
        public string Region { get; set; }
        [ProtoMember(7)]
        public string Country { get; set; }
        [ProtoMember(8)]
        public Double RequestTime
        {
            get; set;
        }

        public static Employee GetEmployee()
        {
            Employee result = new Employee();
            result.EmployeeID = 1;
            result.LastName = "Davolio";
            result.FirstName = "Nancy";
            result.Address = "ja";
            result.City = "Seattle";
            result.Region = "WA";
            result.Country = "USA";
            return result;
        }

        public static List<Employee> GetEmployees(int count)
        {
            List<Employee> result = new List<Employee>();
            for (int i = 0; i < count; i++)
            {

                result.Add(GetEmployee());
            }
            return result;
        }
    }


    [ProtoContract]
    public class SearchEmployee 
    {
        public SearchEmployee()
        {
            ID = 1;
        }
        [ProtoMember(1)]
        public int ID
        {
            get; set;
        }
        [ProtoMember(2)]
        public Double RequestTime
        {
            get; set;
        }
    }
}
