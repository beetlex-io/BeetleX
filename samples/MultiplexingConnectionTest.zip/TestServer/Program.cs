﻿using BeetleX;
using BeetleX.EventArgs;
using BeetleX.Protobuf;
using System;
using TestMessages;

namespace TestServer
{
    public class Program : ServerHandlerBase
    {
        private static IServer mServer;

        private static BeetleX.Dispatchs.MultiThreadDispatcher<Tuple<IServer, ISession, SearchEmployee>> multiThreadDispatcher;

        public static void Main(string[] args)
        {
            multiThreadDispatcher = new BeetleX.Dispatchs.MultiThreadDispatcher<Tuple<IServer, ISession, SearchEmployee>>(Response, 20, 10);
            NetConfig config = new NetConfig();
        
            mServer = SocketFactory.CreateTcpServer<Program, TestMessages.ProtobufPacket>(config);
            mServer.Open();
            while (true)
            {
                Console.Write(mServer);
                Console.WriteLine("{0}/{1}", Count - LastCount, Count);
                LastCount = Count;
                System.Threading.Thread.Sleep(1000);
            }
        }

        private static long Count;

        private static long LastCount;

        public static void Response(Tuple<IServer, ISession, SearchEmployee> value)
        {
            Employee emp = Employee.GetEmployee();
            emp.RequestTime = value.Item3.RequestTime;
            value.Item1.Send(emp, value.Item2);
            System.Threading.Interlocked.Increment(ref Count);
        }
        public override void SessionPacketDecodeCompleted(IServer server, PacketDecodeCompletedEventArgs e)
        {
            SearchEmployee emp = (SearchEmployee)e.Message;
            multiThreadDispatcher.Enqueue(new Tuple<IServer, ISession, SearchEmployee>(server, e.Session, emp));
        }

        public override void SessionReceive(IServer server, SessionReceiveEventArgs e)
        {
            base.SessionReceive(server, e);
        }

    }
}
