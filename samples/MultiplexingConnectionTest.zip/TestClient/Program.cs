﻿using BeetleX;
using BeetleX.Clients;
using BeetleX.Protobuf;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using TestMessages;

namespace TestClient
{
    public class Program
    {

        private static System.Diagnostics.Stopwatch mWatch;

        private const string mIPAddress = "127.0.0.1";

        private const int mConnections = 10;

        private static long mCount;

        private static long mLastCount;

        private static long mLevel1;

        private static long mLevel2;

        private static long mLevel3;

        private static long mLevel4;

        private static long mLevel5;

        private static BeetleX.Dispatchs.MultiThreadDispatcher<Tuple<AsyncTcpClient, Employee>> multiThreadDispatcher;

        private static List<AsyncTcpClient> mClients = new List<AsyncTcpClient>();

        public static void Main(string[] args)
        {
            multiThreadDispatcher = new BeetleX.Dispatchs.MultiThreadDispatcher<Tuple<AsyncTcpClient, Employee>>(Response, 20, 10);
            mWatch = new System.Diagnostics.Stopwatch();
            mWatch.Restart();
            Test();
            while (true)
            {
                Console.WriteLine("* {0}------------------", DateTime.Now);
                Console.WriteLine("* {0}秒/{1}", mCount - mLastCount, mCount);
                mLastCount = mCount;
                Console.WriteLine("* 0.01ms<[{0:000,000,00}]<0.1ms\r\n*  0.1ms<[{1:000,000,00}]<0.5ms\r\n*  0.5ms<[{2:000,000,00}]<1ms\r\n*    1ms<[{3:000,000,00}]<3ms\r\n*    3ms<[{4:000,000,00}]"
                    , mLevel1, mLevel2, mLevel3, mLevel4, mLevel5);
                System.Threading.Thread.Sleep(1000);
            }

        }

        private static void Response(Tuple<AsyncTcpClient, Employee> data)
        {
            System.Threading.Interlocked.Increment(ref mCount);
            if (mCount > 100)
            {
                if (data.Item2.RequestTime > 0)
                {
                    double tick = mWatch.Elapsed.TotalMilliseconds - data.Item2.RequestTime;
                    AddToLevel(tick);
                }
            }
            var s = new SearchEmployee();
            s.RequestTime = mWatch.Elapsed.TotalMilliseconds;
            data.Item1.Send(s);
        }


        private static void AddToLevel(double tick)
        {
            if (tick > 0.01 && tick < 0.1)
            {
                System.Threading.Interlocked.Increment(ref mLevel1);
            }
            else if (tick > 0.1 && tick < 0.5)
            {
                System.Threading.Interlocked.Increment(ref mLevel2);
            }
            else if (tick > 0.5 && tick < 1)
            {
                System.Threading.Interlocked.Increment(ref mLevel3);
            }
            else if (tick > 1 && tick < 3)
            {
                System.Threading.Interlocked.Increment(ref mLevel4);
            }
            else
            {
                System.Threading.Interlocked.Increment(ref mLevel5);
            }
        }

        public static void Test()
        {

            for (int i = 0; i < mConnections; i++)
            {
                var client = SocketFactory.CreateClient<BeetleX.Clients.AsyncTcpClient, TestMessages.ProtobufClientPacket>(mIPAddress, 9090);
                client.ReceivePacket = (o, e) =>
                {
                    Employee emp = (Employee)e;
                    multiThreadDispatcher.Enqueue(new Tuple<AsyncTcpClient, Employee>((AsyncTcpClient)o, emp));
                };
                client.ClientError = (o, e) =>
                {
                    Console.WriteLine(e.Message);
                };
                mClients.Add(client);
            }
            for (int i = 0; i < 200; i++)
            {
                foreach (var item in mClients)
                {
                    SearchEmployee search = new SearchEmployee();
                    Task.Run(() => { item.Send(search); });
                }
            }
        }
    }
}
