﻿using BeetleX;
using BeetleX.Clients;
using PushMessages;
using System;
using System.Collections.Generic;

namespace PushClient
{
    class Program
    {

        // public const string Host = "localhost";

        public const string Host = "172.31.117.25";

        public const int Port = 9090;

        public const int Connections = 5;

        public static BeetleX.Buffers.BufferPool BufferPool;

        private static long LastCount;

        static void Main(string[] args)
        {
            BufferPool = new BeetleX.Buffers.BufferPool(1024 * 32, 1000);
            PushCenter pushCenter = new PushCenter(Host, Port, Connections);
            pushCenter.Run();
            while (true)
            {
                long count = pushCenter.Count;
                Console.WriteLine("[{3}] {0:000,000,000}/{1:000,000,000,000} MaxID:{2}",
                    count - LastCount, count, pushCenter.MaxOrerID, DateTime.Now);
                LastCount = count;
                System.Threading.Thread.Sleep(1000);
            }
        }
    }

    public class PushCenter
    {
        public PushCenter(string host, int port, int connections)
        {

            for (int i = 0; i < connections; i++)
            {
                AsyncTcpClient client = SocketFactory.CreateClient<BeetleX.Clients.AsyncTcpClient, ClientPacket>(host, port);
                client.BufferPool = Program.BufferPool;
                client.ClientError = (o, e) =>
                {
                    Console.WriteLine(e.Error.Message);
                };
                client.Connect();
                mClients.Add(client);
            }
        }


        public long Count;

        public long MaxOrerID;

        private List<AsyncTcpClient> mClients = new List<AsyncTcpClient>();

        public List<AsyncTcpClient> Clients => mClients;

        public void Run()
        {
            foreach (var item in mClients)
                System.Threading.ThreadPool.QueueUserWorkItem(OnRun, item);
        }

        private void OnRun(object state)
        {
            AsyncTcpClient item = (AsyncTcpClient)state;
            while (true)
            {
                Order order = OrderFactory.CreateOrder();
                item.Send(order);
                if (order.ID > MaxOrerID)
                    MaxOrerID = order.ID;
                System.Threading.Interlocked.Increment(ref Count);
                if (item.Count > 2000)
                    System.Threading.Thread.Sleep(1);
            }
        }

    }
}
