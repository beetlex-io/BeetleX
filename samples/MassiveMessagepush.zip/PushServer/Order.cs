﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;
using BeetleX;
using BeetleX.Buffers;
using BeetleX.Clients;

namespace PushMessages
{
    public class Order
    {
        public long ID;
        public string Product;
        public int Quantity;
        public double Price;
        public double Total;
    }

    public class OrderFactory
    {
        [ThreadStatic]
        private static byte[] mBuffer;

        public static byte[] Buffer
        {
            get
            {
                if (mBuffer == null)
                    mBuffer = new byte[1024];
                return mBuffer;
            }
        }

        private static long mId;
        private static string[] mProducts = new string[] { "Apple", "Orange", "Banana", "Citrus", "Mango" };
        private static int[] mQuantity = new int[] { 3, 10, 20, 23, 6, 9, 21 };
        private static double[] mPrice = new double[] { 2.3, 1.6, 3.2, 4.6, 20, 4 };
        public static Order CreateOrder()
        {
            Order order = new Order();
            order.ID = System.Threading.Interlocked.Increment(ref mId);
            order.Product = mProducts[order.ID % mPrice.Length];
            order.Quantity = mQuantity[order.ID % mQuantity.Length];
            order.Price = mPrice[order.ID % mPrice.Length];
            order.Total = order.Quantity * order.Price;
            return order;
        }

        public unsafe static void Serialization(PipeStream stream, Order order)
        {
            double value;
            byte[] buffer = Buffer;
            int postion = 0;
            BitHelper.Write(buffer, postion, order.ID);
            postion += 8;
            Encoding.ASCII.GetBytes(order.Product, 0, order.Product.Length, buffer, postion);
            postion += 10;
            BitHelper.Write(buffer, postion, order.Quantity);
            postion += 4;
            value = order.Price;
            BitHelper.Write(buffer, postion, *(long*)(&value));
            postion += 8;
            value = order.Total;
            BitHelper.Write(buffer, postion, *(long*)(&value));
            postion += 8;
            stream.Write(buffer, 0, postion);
        }

        public unsafe static Order Deserialization(PipeStream stream, int length)
        {
            byte[] buffer = Buffer;
            stream.Read(buffer, 0, length);
            Order order = new Order();
            long value;
            int postion = 0;
            order.ID = BitHelper.ReadInt64(buffer, postion);
            postion += 8;
            order.Product = Encoding.ASCII.GetString(buffer, postion, 10);
            postion += 10;
            order.Quantity = BitHelper.ReadInt32(buffer, postion);
            postion += 4;
            value = BitHelper.ReadInt64(buffer, postion);
            order.Price = *(double*)(&value);
            postion += 8;
            value = BitHelper.ReadInt64(buffer, postion);
            order.Total = *(double*)(&value);
            postion += 8;
            return order;
        }
    }

    public class Packet : BeetleX.Packets.FixedHeaderPacket
    {
        public override IPacket Clone()
        {
            return new Packet();
        }

        protected override object OnReader(ISession session, PipeStream stream)
        {
            return OrderFactory.Deserialization(stream, CurrentSize);
        }

        protected override void OnWrite(ISession session, object data, PipeStream stream)
        {
            OrderFactory.Serialization(stream, (Order)data);
        }
    }

    public class ClientPacket : BeetleX.Packets.FixeHeaderClientPacket
    {
        public override IClientPacket Clone()
        {
            return new ClientPacket();
        }

        protected override object OnRead(IClient client, PipeStream stream)
        {
            return OrderFactory.Deserialization(stream, CurrentSize);
        }

        protected override void OnWrite(object data, IClient client, PipeStream stream)
        {
            OrderFactory.Serialization(stream, (Order)data);
        }
    }

}
