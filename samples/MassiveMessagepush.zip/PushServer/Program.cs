﻿using BeetleX;
using BeetleX.EventArgs;
using System;

namespace PushServer
{
    public class Program : ServerHandlerBase
    {
        private static IServer mServer;

        public static void Main(string[] args)
        {
            NetConfig config = new NetConfig();
            config.BufferSize = 1024 * 32;
            mServer = SocketFactory.CreateTcpServer<Program, PushMessages.Packet>(config);
            mServer.Open();
            while (true)
            {
                Console.Write(mServer);
                Console.WriteLine("[{3}] {0:000,000,000}/{1:000,000,000,000} MaxID:{2}", Count - LastCount, Count, MaxOrerID, DateTime.Now);
                LastCount = Count;
                System.Threading.Thread.Sleep(1000);
            }
        }

        public override void Connecting(IServer server, ConnectingEventArgs e)
        {
            e.Socket.ReceiveBufferSize = 1024 * 32;
            base.Connecting(server, e);
        }

        public override void Connected(IServer server, ConnectedEventArgs e)
        {

            base.Connected(server, e);
        }

        private static long Count;

        private static long LastCount;

        private static long MaxOrerID;

        public override void SessionPacketDecodeCompleted(IServer server, PacketDecodeCompletedEventArgs e)
        {
            PushMessages.Order order = (PushMessages.Order)e.Message;
            if (order.ID > MaxOrerID)
                MaxOrerID = order.ID;
            System.Threading.Interlocked.Increment(ref Count);
        }

        public override void SessionReceive(IServer server, SessionReceiveEventArgs e)
        {
            base.SessionReceive(server, e);
        }

    }
}
