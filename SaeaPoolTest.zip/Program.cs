﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Threading.Tasks;

namespace SaeaPoolTest
{
    class Program
    {
        static void Main(string[] args)
        {
            Pool.Completed = OnCompleted;
            OpenListen();
            Console.WriteLine("SocketAsyncEventArgs pool testing...");
            Console.Read();
        }

        private static Socket serverSocket;

        private static void OpenListen()
        {
            System.Net.IPAddress address;
            if (Socket.OSSupportsIPv6)
            {
                address = IPAddress.IPv6Any;
            }
            else
            {
                address = IPAddress.Any;
            }
            var iPEndPoint = new System.Net.IPEndPoint(address, 9090);
            serverSocket = new Socket(iPEndPoint.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
            if (iPEndPoint.Address == IPAddress.IPv6Any)
            {
                serverSocket.DualMode = true;
            }
            serverSocket.Bind(iPEndPoint);
            serverSocket.Listen(512);
            Task.Run(() => Accept());
        }

        private static void Accept()
        {
            while (true)
            {
                var acceptSocket = serverSocket.Accept();
                Task.Run(() => BeginReceive(acceptSocket));
            }
        }

        private static void OnCompleted(object sender, SocketAsyncEventArgs e)
        {
            if (e.LastOperation == SocketAsyncOperation.Send)
            {
                OnSendCompleted(e);
            }
            else if (e.LastOperation == SocketAsyncOperation.Receive)
            {
                OnReceiveCompleted(e);
            }
        }

        private static void BeginReceive(Socket socket)
        {
            SocketAsyncEventArgs eventArgs = Pool.Dequeue();
            eventArgs.SetBuffer(0, Pool.BufferSize);
            eventArgs.UserToken = socket;
            if (!socket.ReceiveAsync(eventArgs))
            {
                OnReceiveCompleted(eventArgs);
            }
        }

        private static void OnReceiveCompleted(SocketAsyncEventArgs e)
        {
            try
            {
                if (e.SocketError == SocketError.Success && e.BytesTransferred > 0)
                {
                    Socket socket = (Socket)e.UserToken;
                    try
                    {
                        string requestText = System.Text.Encoding.UTF8.GetString(e.Buffer, 0, e.BytesTransferred);
                        byte[] responseData = System.Text.Encoding.UTF8.GetBytes(requestText);
                        System.Text.StringBuilder sb = new System.Text.StringBuilder();
                        sb.AppendLine("HTTP/1.1 200 OK");
                        sb.AppendLine("Content-Type: text/html; charset=UTF-8");
                        sb.AppendLine("Content-Length: " + responseData.Length);
                        sb.AppendLine("");
                        int offset = 0, count = 0;
                        string header = sb.ToString();
                        SocketAsyncEventArgs eventArgs = Pool.Dequeue();
                        var buffer = eventArgs.Buffer;
                        offset += System.Text.Encoding.UTF8.GetBytes(header, 0, header.Length, buffer, offset);
                        System.Buffer.BlockCopy(responseData, 0, buffer, offset, responseData.Length);
                        count = offset + responseData.Length;
                        eventArgs.SetBuffer(0, count);
                        if (!socket.SendAsync(eventArgs))
                        {
                            OnSendCompleted(eventArgs);
                        }

                    }
                    finally
                    {
                        BeginReceive(socket);
                    }
                }
            }
            finally
            {
                Pool.Enqueue(e);
            }
        }

        private static void OnSendCompleted(SocketAsyncEventArgs e)
        {
            try
            {

            }
            finally
            {
                Pool.Enqueue(e);
            }
        }
    }
}
