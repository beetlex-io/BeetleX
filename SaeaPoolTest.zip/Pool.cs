﻿using System;
using System.Collections.Generic;
using System.Net.Sockets;
using System.Text;

namespace SaeaPoolTest
{
    public class Pool
    {

        public const int BufferSize = 1024 * 8;

        public static EventHandler<SocketAsyncEventArgs> Completed { get; set; }

        private static System.Collections.Concurrent.ConcurrentQueue<SocketAsyncEventArgs> eventArgsPool = new System.Collections.Concurrent.ConcurrentQueue<SocketAsyncEventArgs>();

        public static SocketAsyncEventArgs Dequeue()
        {
            if (eventArgsPool.TryDequeue(out SocketAsyncEventArgs eventArgs))
                return eventArgs;
            else
            {
                eventArgs = new SocketAsyncEventArgs();
                eventArgs.SetBuffer(new byte[BufferSize], 0, BufferSize);
                eventArgs.Completed += Completed;
                return eventArgs;
            }
        }

        public static void Enqueue(SocketAsyncEventArgs eventArgs)
        {
            eventArgsPool.Enqueue(eventArgs);
        }
    }
}
